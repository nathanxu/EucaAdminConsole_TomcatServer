/*************************************************************************
 * Copyright 2009-2012 Eucalyptus Systems, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/.
 *
 * Please contact Eucalyptus Systems, Inc., 6755 Hollister Ave., Goleta
 * CA 93117, USA or visit http://www.eucalyptus.com/licenses/ if you need
 * additional information or have any questions.
 ************************************************************************/

(function($, eucalyptus) {
    $.widget('eucalyptus.cloudmanagement_policy', $.eucalyptus.eucawidget, {
        options : { },
        baseTable : null,
        tableWrapper : null,
        _init : function() {
            var thisObj = this;
            var $tmpl = $('html body div.templates').find('#policyTmpl').clone();
            var $wrapper = $($tmpl.render($.i18n.map));
            var $configurecloud = $wrapper.children().first();
            var $help = $wrapper.children().last();

            var $instTable = $configurecloud.children('.inner-table');
            thisObj.tableWrapper = $instTable.innertable({
                id : 'cloudmanagement_policy', // user of this widget should customize these options,
                data_deps : ['cloudmanagement_policy'],
                hidden : thisObj.options['hidden'],
                dt_arg : {
                    "sAjaxSource" : 'cloudmanagement_policy',
                    "aaSorting" : [[3, "desc"]],
                    "aoColumnDefs" : [{
                        "bSortable" : false,
                        "aTargets" : [0],
                        "mData" : function(source) {
                            return '<input type="checkbox"/>';
                        },
                        "sClass" : "checkbox-cell",
                    }, {
                        "aTargets" : [1],
                        "mData" : function(source) {
                            return source.name;
                        },
                    }, {
                        "aTargets" : [2],
                        "mData" : function(source) {
                            return source.type;
                        },
                    }, {
                        "aTargets" : [3],
                        "mData" : function(source) {
                            return '456';
                        },
                    }, {
                        "aTargets" : [4],
                        "mData" : function(source) {
                            return source;
                        },
                    }, {
                        "aTargets" : [5],
                        "mData" : function(source) {
                            return '123';
                        },
                    }, {
                        "aTargets" : [6],
                        "mData" : function(source) {
                            return '456';
                        },
                    },
                    ]
                },
                text : {
                    create_resource : gloable_new,
                    resource_found : 'record_found',
                    resource_search : record_search,
                    resource_plural : record_plural,
                },
                menu_click_create : function(e) {
                    thisObj.addDialog.eucadialog('open');
                },
                menu_actions : function(args) {
                    return {
                        'Delete' : {
                            "name" : gloable_delete,
                            callback : function(key, opt) {
                                var itemsToDelete = [];
                                var $tableWrapper = thisObj.tableWrapper;
                                itemsToDelete = $tableWrapper.innertable('getSelectedRows', 1);
                                var matrix = [];
                                $.each(itemsToDelete,function(idx, key){
                                  matrix.push([key, key]);
                                });
                                if ( itemsToDelete.length > 0 ) {
                                  thisObj.delDialog.eucadialog('setSelectedResources', {title:[account_subtitle], contents: matrix, limit:60, hideColumn: 1});
                                  thisObj.delDialog.dialog('open');
                                }
                            }
                        },
                        'Assign_User' : {
                            "name" : policy_assignuser,
                            callback : function(key, opt) {
                                items = thisObj.tableWrapper.innertable('getSelectedRows', 1);
                                if (items.length != 1) {
                                    notifySuccess($.i18n.prop('error_msg_select_one', DefaultEncoder().encodeForHTML($.i18n.map.policy_subtitle)));
                                    return false;
                                } 
                                var matrix = [];
                                $.ajax({
                                type:"POST",
                                url:"ea.cloudmanagement.PolicyAction$getPolicyByUser.json",
                                data:{account: items[0]},
                                dataType:"json",
                                async:false,
                                  success:function(data){
                                      $.each(describe('cloudmanagement_policy'), function(idx1,item) {
                                          var flg = false;
                                          $.each(data, function(idx2, checkedItem) {
                                              if (checkedItem.name == item.name) {
                                                  flg = true;
                                                  return false;
                                              }
                                          });
                                          if (flg) {
                                             matrix.push([item.name,
                                                          $.i18n.map.policy_name+': '+item.name+'\n'+
                                                          $.i18n.map.policy_type+': '+item.type+'\n'+
                                                          $.i18n.map.policy_action+': '+item.action+'\n'+
                                                          $.i18n.map.policy_resource+': '+item.resource+'\n'+
                                                          $.i18n.map.policy_condition+': '+item.condition+'\n'+
                                                          $.i18n.map.policy_effect+': '+item.effect,
                                                          true]); 
                                          } else {
                                             matrix.push([item.name,
                                                          $.i18n.map.policy_name+': '+item.name+'\n'+
                                                          $.i18n.map.policy_type+': '+item.type+'\n'+
                                                          $.i18n.map.policy_action+': '+item.action+'\n'+
                                                          $.i18n.map.policy_resource+': '+item.resource+'\n'+
                                                          $.i18n.map.policy_condition+': '+item.condition+'\n'+
                                                          $.i18n.map.policy_effect+': '+item.effect,
                                                          false]);                                      
                                          }
                                      });
                                  },
                                });
                                if ( matrix.length > 0 ) {
                                  thisObj.assignUserDialog.eucadialog('setSelectedResourcesWithCheckbox', {contents: matrix});
                                  thisObj.assignUserDialog.find(".selected-resources").hcheckbox();
                                }
                                thisObj.assignUserDialog.dialog('open');
                            }
                        },
                        'Assign_UserGroup' : {
                            "name" : policy_assignusergroup,
                            callback : function(key, opt) {
                                items = thisObj.tableWrapper.innertable('getSelectedRows', 1);
                                if (items.length != 1) {
                                    notifySuccess($.i18n.prop('error_msg_select_one', DefaultEncoder().encodeForHTML($.i18n.map.policy_subtitle)));
                                    return false;
                                } 
                                var matrix = [];
                                $.ajax({
                                type:"POST",
                                url:"ea.cloudmanagement.PolicyAction$getPolicyByUser.json",
                                data:{account: items[0]},
                                dataType:"json",
                                async:false,
                                  success:function(data){
                                      $.each(describe('cloudmanagement_policy'), function(idx1,item) {
                                          var flg = false;
                                          $.each(data, function(idx2, checkedItem) {
                                              if (checkedItem.name == item.name) {
                                                  flg = true;
                                                  return false;
                                              }
                                          });
                                          if (flg) {
                                             matrix.push([item.name,
                                                          $.i18n.map.policy_name+': '+item.name+'\n'+
                                                          $.i18n.map.policy_type+': '+item.type+'\n'+
                                                          $.i18n.map.policy_action+': '+item.action+'\n'+
                                                          $.i18n.map.policy_resource+': '+item.resource+'\n'+
                                                          $.i18n.map.policy_condition+': '+item.condition+'\n'+
                                                          $.i18n.map.policy_effect+': '+item.effect,
                                                          true]); 
                                          } else {
                                             matrix.push([item.name,
                                                          $.i18n.map.policy_name+': '+item.name+'\n'+
                                                          $.i18n.map.policy_type+': '+item.type+'\n'+
                                                          $.i18n.map.policy_action+': '+item.action+'\n'+
                                                          $.i18n.map.policy_resource+': '+item.resource+'\n'+
                                                          $.i18n.map.policy_condition+': '+item.condition+'\n'+
                                                          $.i18n.map.policy_effect+': '+item.effect,
                                                          false]);                                      
                                          }
                                      });
                                  },
                                });
                                if ( matrix.length > 0 ) {
                                  thisObj.assignUserGroupDialog.eucadialog('setSelectedResourcesWithCheckbox', {contents: matrix});
                                  thisObj.assignUserGroupDialog.find(".selected-resources").hcheckbox();
                                }
                                thisObj.assignUserGroupDialog.dialog('open');
                            }
                        },
                        'Assign_Account' : {
                            "name" : policy_assignaccount,
                            callback : function(key, opt) {
                                items = thisObj.tableWrapper.innertable('getSelectedRows', 1);
                                if (items.length != 1) {
                                    notifySuccess($.i18n.prop('error_msg_select_one', DefaultEncoder().encodeForHTML($.i18n.map.policy_subtitle)));
                                    return false;
                                } 
                                var matrix = [];
                                $.ajax({
                                type:"POST",
                                url:"ea.cloudmanagement.PolicyAction$getPolicyByUser.json",
                                data:{account: items[0]},
                                dataType:"json",
                                async:false,
                                  success:function(data){
                                      $.each(describe('cloudmanagement_policy'), function(idx1,item) {
                                          var flg = false;
                                          $.each(data, function(idx2, checkedItem) {
                                              if (checkedItem.name == item.name) {
                                                  flg = true;
                                                  return false;
                                              }
                                          });
                                          if (flg) {
                                             matrix.push([item.name,
                                                          $.i18n.map.policy_name+': '+item.name+'\n'+
                                                          $.i18n.map.policy_type+': '+item.type+'\n'+
                                                          $.i18n.map.policy_action+': '+item.action+'\n'+
                                                          $.i18n.map.policy_resource+': '+item.resource+'\n'+
                                                          $.i18n.map.policy_condition+': '+item.condition+'\n'+
                                                          $.i18n.map.policy_effect+': '+item.effect,
                                                          true]); 
                                          } else {
                                             matrix.push([item.name,
                                                          $.i18n.map.policy_name+': '+item.name+'\n'+
                                                          $.i18n.map.policy_type+': '+item.type+'\n'+
                                                          $.i18n.map.policy_action+': '+item.action+'\n'+
                                                          $.i18n.map.policy_resource+': '+item.resource+'\n'+
                                                          $.i18n.map.policy_condition+': '+item.condition+'\n'+
                                                          $.i18n.map.policy_effect+': '+item.effect,
                                                          false]);                                      
                                          }
                                      });
                                  },
                                });
                                if ( matrix.length > 0 ) {
                                  thisObj.assignAccountDialog.eucadialog('setSelectedResourcesWithCheckbox', {contents: matrix});
                                  thisObj.assignAccountDialog.find(".selected-resources").hcheckbox();
                                }
                                thisObj.assignAccountDialog.dialog('open');
                            }
                        }
                    };
                },
            });
            //end of eucatable

            var $wrapper = $('<div>').addClass('innertable-wrapper');
            $configurecloud.appendTo($wrapper);
            $wrapper.appendTo(this.element);

        },

        _create : function() {
            var thisObj = this;
            var createButtonId = "keys-add-btn";
            var $tmpl = $('html body div.templates').find('#addPolicyDlgTmpl').clone();
            var $rendered = $($tmpl.render($.extend($.i18n.map)));
            var $add_dialog = $rendered.children().first();
            this.addDialog = $add_dialog.eucadialog({
                id : 'keys-add',
                title : policy_addpolicy,
                width : 500,
                buttons : {
                    // e.g., add : { domid: keys-add-btn, text: "Add new key", disabled: true, focus: true, click : function() { }, keypress : function() { }, ...}
                    'create' : {
                        domid : createButtonId,
                        text : button_add,
                        disabled : true,
                        click : function() {
                            var name = $.trim(asText($add_dialog.find('#name').val()));
                            var type = $.trim(asText($add_dialog.find('#type').val()));
                            var action = $.trim(asText($add_dialog.find('#action').val()));
                            var resource = $.trim(asText($add_dialog.find('#resource').val()));
                            var condition = $.trim(asText($add_dialog.find('#condition').val()));
                            var effect = $.trim(asText($add_dialog.find('#effect').val()));
                            $add_dialog.eucadialog("close");
                            var model = {
                                name : name,
                                type : type,
                                action : action,
                                resource : resource,
                                condition : condition,
                                effect : effect
                            }; 
                            thisObj._addAction(model);
                            ;
                        }
                    },
                    'cancel' : {
                        domid : 'keys-cancel-btn',
                        text : button_cancel,
                        click : function() {
                            $add_dialog.eucadialog("close");
                        }
                    },
                },
            });

            $add_dialog.find("#name").watermark(watermark_input_name);
            $add_dialog.eucadialog('buttonOnKeyupNew', $add_dialog.find('#name'), createButtonId, function(val) {
                var name = $.trim($add_dialog.find('#name').val());
                if (!INFRASTRACTURE_NAME_PATTERN.test(name)) {
                    thisObj.addDialog.eucadialog('showError', error_msg_infrastracture_name);
                } else {
                    thisObj.addDialog.eucadialog('showError', null);
                }
                return INFRASTRACTURE_NAME_PATTERN.test(name);
            });
            
            var $tmpl = $('html body').find('#deleteDlgTmpl').clone();
            var $rendered = $($tmpl.render($.extend($.i18n.map)));
            var $del_dialog = $rendered.children().first();
            $del_dialog.find(".selected-resources").before($.i18n.map.text_del_component);
            this.delDialog = $del_dialog.eucadialog({
                id : 'keys-delete',
                title : account_deletaccount,
                width : 500,
                buttons : {
                    'delete' : {
                        text : button_delete,
                        click : function() {
                            var itemsToDelete = thisObj.delDialog.eucadialog('getSelectedResourcesString', 1);
                            $del_dialog.eucadialog("close");
                            thisObj._deleteAction(itemsToDelete);
                        }
                    },
                    'cancel' : {
                        text : button_cancel,
                        focus : true,
                        click : function() {
                            $del_dialog.eucadialog("close");
                        }
                    }
                },
            }); 

            var $tmpl = $('html body').find('#deleteMultipleDlgTmpl').clone();
            var $rendered = $($tmpl.render($.extend($.i18n.map)));
            var $assignUser_dialog = $rendered.children().first();
            this.assignUserDialog = $assignUser_dialog.eucadialog({
               id: 'keys-delete',
               width: 500,
               title: policy_assignuser,
               buttons: {
                 'save': {
                     text: button_save, 
                     click: function() {
                      var items = thisObj.assignUserDialog.eucadialog('getSelectedCheckedResources');
                      if (items.length < 1) {
                          thisObj.assignUserDialog.eucadialog('showError',error_msg_multiple_delete);
                      } else {
                          $assignUser_dialog.eucadialog("close");
                          thisObj._assignUserAction(items);
                      }
                   }},
                 'cancel': {text: button_cancel, focus:true, click: function() { $assignUser_dialog.eucadialog("close");}} 
               },
             });
             
            var $tmpl = $('html body').find('#deleteMultipleDlgTmpl').clone();
            var $rendered = $($tmpl.render($.extend($.i18n.map)));
            var $assignUserGroup_dialog = $rendered.children().first();
            this.assignUserGroupDialog = $assignUserGroup_dialog.eucadialog({
               id: 'keys-delete',
               width: 500,
               title: policy_assignusergroup,
               buttons: {
                 'save': {
                     text: button_save, 
                     click: function() {
                      var items = thisObj.assignUserGroupDialog.eucadialog('getSelectedCheckedResources');
                      if (items.length < 1) {
                          thisObj.assignUserGroupDialog.eucadialog('showError',error_msg_multiple_delete);
                      } else {
                          $assignUserGroup_dialog.eucadialog("close");
                          thisObj._assignUserGroupAction(items);
                      }
                   }},
                 'cancel': {text: button_cancel, focus:true, click: function() { $assignUserGroup_dialog.eucadialog("close");}} 
               },
             });
             
            var $tmpl = $('html body').find('#deleteMultipleDlgTmpl').clone();
            var $rendered = $($tmpl.render($.extend($.i18n.map)));
            var $assignAccount_dialog = $rendered.children().first();
            this.assignAccountDialog = $assignAccount_dialog.eucadialog({
               id: 'keys-delete',
               width: 500,
               title: policy_assignaccount,
               buttons: {
                 'save': {
                     text: button_save, 
                     click: function() {
                      var items = thisObj.assignAccountDialog.eucadialog('getSelectedCheckedResources');
                      if (items.length < 1) {
                          thisObj.assignAccountDialog.eucadialog('showError',error_msg_multiple_delete);
                      } else {
                          $assignAccount_dialog.eucadialog("close");
                          thisObj._assignAccountAction(items);
                      }
                   }},
                 'cancel': {text: button_cancel, focus:true, click: function() { $assignAccount_dialog.eucadialog("close");}} 
               },
             });
        },
        
        _addAction : function(model) {
            var thisObj = this;
            $.ajax({
                type : "POST",
                url : "ea.cloudmanagement.PolicyAction$addPolicy.json",
                data : model,
                dataType : "json",
                async : false,
                success : function(data) {
                    notifySuccess($.i18n.map.success_msg_del, "name:" + data.name);
                    require(['app'], function(app) {
                        app.data.cloudmanagement_policy.fetch();
                    });
                    thisObj.tableWrapper.innertable('refreshTable');
                },
                error : function(jqXHR, textStatus, errorThrown) {
                    notifyError($.i18n.map.error_msg_del, getErrorMessage(jqXHR));
                }
            });
        },
        
        _deleteAction : function(items) {
            var thisObj = this;
            $.ajax({
                type : "POST",
                url : "ea.cloudmanagement.PolicyAction$deletePolicy.json",
                data : items,
                dataType : "json",
                async : false,
                success : function(data) {
                   var notifyMsg = "";
                   $.each(data, function(idx, value) {
                      notifyMsg += ("name:"+ value + "<br>");
                   });                    
                    notifySuccess($.i18n.map.success_msg_del, notifyMsg);
                    require(['app'], function(app) {
                        app.data.cloudmanagement_policy.fetch();
                    });
                    thisObj.tableWrapper.innertable('refreshTable');
                },
                error : function(jqXHR, textStatus, errorThrown) {
                    notifyError($.i18n.map.error_msg_add, getErrorMessage(jqXHR));
                }
            });
        },
        
        _assignUserGroupAction : function(items) {
            alert(2);  
        },
        
        _assignUserAction : function(items) {
            alert(1);
        },
        
        _assignAccountAction : function(itmes) {
            alert(3);
        }

    });
})(jQuery, window.eucalyptus ? window.eucalyptus : window.eucalyptus = {});
