define([
    'underscore',
    'backbone',
    'sharedtags',
    'models/scalinggrps',
	'models/scalinginsts',
	'models/scalingpolicys',
	'models/volumes',
	'models/images',
	'models/launchconfigs',
	'models/instances',
	'models/eips',
	'models/keypairs',
	'models/sgroups',
	'models/snapshots',
	'models/balancers',
	'models/insthealths',
	'models/summarys',
	'models/zones',
	'models/buckets',
	'models/alarms',
	'models/metrics',
    'models/availabilityzones',
    
    'models/configurecloud_loadbalancers',
    'models/configurecloud_cloudproperties',
    'models/configurecloud_vmtypes',
    'models/configurecloud_ebsservices',
    'models/configurecloud_s3s',
    'models/configurecloud_dnsservices',

    'models/cloudmanagement_accounts',
    'models/cloudmanagement_users',
    'models/cloudmanagement_usergroups',
    'models/cloudmanagement_policys',
    'models/cloudmanagement_credentials',
    'models/cloudmanagement_manageimages',
    'models/cloudmanagement_healthcheckings',
    
    'models/infrastructure_ccs',
    'models/infrastructure_scs',
    'models/infrastructure_vmwarebrokers',
    'models/infrastructure_nodes',
    'models/infrastructure_clcs',
    'models/infrastructure_walruses',
    'models/infrastructure_storages'
	], 
function(_, Backbone, tags) {
    var self = this;
    var sconfs = [
    ['scalinggrp', 'scalinggroup', 'scalingGroup', 'scalingGroups'],
	['scalinginst', 'scalinginsts'],
	['scalingpolicy', 'scalingpolicys'],
	['volume', 'volumes'],
	['image', 'images'],
	['launchconfig', 'launchconfigs', 'launchConfigs'],
	['instance', 'instances'],
	['eip'],
	['keypair', 'keypairs'],
	['sgroup', 'sgroups'],
	['snapshot', 'snapshots'],
	['balancer'],
	['insthealth', 'instHealths'],
	['summary'],
	['zone', 'zones'],
	['bucket'],
	['alarm', 'alarms'],
	['metrics'],
	['availabilityzone'],
	
	['configurecloud_loadbalancer', 'configurecloud_loadbalancers'],
	['configurecloud_cloudproperty', 'configurecloud_cloudproperties'],
	['configurecloud_vmtype', 'configurecloud_vmtypes'],
	['configurecloud_ebsservice', 'configurecloud_ebsservices'],
	['configurecloud_s3', 'configurecloud_s3s'],
	['configurecloud_dnsservice', 'configurecloud_dnsservices'],

	['cloudmanagement_account', 'cloudmanagement_accounts'],
	['cloudmanagement_user', 'cloudmanagement_users'],
	['cloudmanagement_usergroup', 'cloudmanagement_usergroups'],
	['cloudmanagement_policy', 'cloudmanagement_policys'],
	['cloudmanagement_credential', 'cloudmanagement_credentials'],
	['cloudmanagement_manageimage', 'cloudmanagement_manageimages'],
    ['cloudmanagement_healthchecking', 'cloudmanagement_healthcheckings'],
    
	['infrastructure_cc', 'infrastructure_ccs'],
	['infrastructure_sc', 'infrastructure_scs'],
	['infrastructure_vmwarebroker', 'infrastructure_vmwarebrokers'],
	['infrastructure_node', 'infrastructure_nodes'],
    ['infrastructure_clc', 'infrastructure_clcs'],
    ['infrastructure_walrus', 'infrastructure_walruses'],
    ['infrastructure_storage', 'infrastructure_storages']
    ];

    var shared = {};
    var args = arguments;
    var srcs = _.map(_.range(3, args.length), function(n) { 
        return args[n]; 
    });
    _.each(srcs, function(src, index) {
       var clz = srcs[index];
       var obj = new clz();
       _.each(sconfs[index], function(name) {
           shared[name] = obj;
       });
    });

    shared.tags = tags;
    shared.tag = tags;
 
	return shared;
});
