/*************************************************************************
 * Copyright 2009-2012 Eucalyptus Systems, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/.
 *
 * Please contact Eucalyptus Systems, Inc., 6755 Hollister Ave., Goleta
 * CA 93117, USA or visit http://www.eucalyptus.com/licenses/ if you need
 * additional information or have any questions.
 ************************************************************************/

(function($, eucalyptus) {
  $.widget('eucalyptus.cloudmanagement_account', $.eucalyptus.eucawidget, {
    options : { },
    baseTable : null,
    tableWrapper : null,
    _init : function() {
      thisObj = this;
      var $tmpl = $('html body div.templates').find('#accountTmpl').clone();    
      var $wrapper = $($tmpl.render($.i18n.map));
      var $configurecloud = $wrapper.children().first();
      var $help = $wrapper.children().last(); 
      
      var $instTable = $configurecloud.children('.inner-table');
      thisObj.tableWrapper = $instTable.innertable({
          id : 'cloudmanagement_account', // user of this widget should customize these options,
          data_deps: ['cloudmanagement_account'],
          hidden: thisObj.options['hidden'],
          dt_arg : {
            "sAjaxSource": 'cloudmanagement_account',
            "aaSorting": [[ 3, "desc" ]],
            "aoColumnDefs": [
              {
                "bSortable": false,
                "aTargets":[0],
                "mData": function(source) { return '<input type="checkbox"/>'; },
                "sClass": "checkbox-cell",
              },
              {
            	"aTargets":[1],
                "mData": function(source){
                  return source.name;
                },
              },
              {
                "aTargets":[2],
                "mData": function(source) { 
                	return source.status;
                },
              }
            ]
          },
          text : {
            create_resource : gloable_new,
            resource_found : 'record_found',
            resource_search : record_search,
            resource_plural : record_plural,
          },
          menu_click_create : function(e) {
        	  thisObj.addDialog.eucadialog('open');
          },            
          menu_actions : function(args){
				return {
					'Delete' : {
						"name" : gloable_delete,
      					callback : function() {
      				        var itemsToDelete = [];
      				        var $tableWrapper = thisObj.tableWrapper;
      				        itemsToDelete = $tableWrapper.innertable('getSelectedRows', 1);
      				        var matrix = [];
      				        $.each(itemsToDelete,function(idx, key){
      				          matrix.push([key, key]);
      				        });
      				        if ( itemsToDelete.length > 0 ) {
      				          thisObj.delDialog.eucadialog('setSelectedResources', {title:[account_subtitle], contents: matrix, limit:60, hideColumn: 1});
      				          thisObj.delDialog.dialog('open');
      				        }
      					  }
						},
						'Add_User' : {
							"name" : account_adduser,
							callback : function(key, opt) {
								items = thisObj.tableWrapper.innertable('getSelectedRows', 1);
								if (items.length != 1) {
									notifySuccess($.i18n.prop('error_msg_select_one', $.i18n.map.account_subtitle));
									return false;
								} 
								thisObj.addUserDialog.find("#account").before('<span id="account">' +items[0]+'</span>').remove();
								thisObj.addUserDialog.eucadialog('open');
							}
						},
						'Add_UserGroup' : {
							"name" : account_addusergroup,
							callback : function(key, opt) {
								items = thisObj.tableWrapper.innertable('getSelectedRows', 1);
								if (items.length != 1) {
									notifySuccess($.i18n.prop('error_msg_select_one', $.i18n.map.account_subtitle));
									return false;
								} 
								thisObj.addUserGroupDialog.find("#account").before('<span id="account">' +items[0]+'</span>').remove();
								thisObj.addUserGroupDialog.eucadialog('open');
							}
						},
						'Delete_User' : {
							"name" : account_deleteuser,
							callback : function(key, opt) {
	      				        var itemsToDelete = [];
	      				        var $tableWrapper = thisObj.tableWrapper;
	      				        itemsToDelete = $tableWrapper.innertable('getSelectedRows', 1);
	      				        var matrix = [];
	      				        $.each(itemsToDelete,function(idx, key){        
	      				          $.ajax({
	      				          type:"POST",
	      				          url:"ea.cloudmanagement.UserAction$getUserByAccount.json",
	      				          data:{account: key},
	      				          dataType:"json",
	      				          async:false,
		      				          success:function(data){
		      				        	  $.each(data, function(idx, val) {
		      				        		  matrix.push([val.name,
	            				        			       $.i18n.map.user_name+': '+val.name+'\n'+
	            				        			       $.i18n.map.user_account+': '+val.account+'\n'+
	            				        			       $.i18n.map.user_group+': '+val.userGroup+'\n'+
	            				        			       $.i18n.map.user_status+': '+val.status,
	            				        			       false]);
		      				        	  });
		      				          },
	      				          });
	      				        });

	      				        if ( matrix.length > 0 ) {
	      				          thisObj.delUserDialog.eucadialog('setSelectedResourcesWithCheckbox', {contents: matrix});
	      				          thisObj.delUserDialog.find(".selected-resources").hcheckbox();
	      				        }
	      				        thisObj.delUserDialog.find('.checkbox').bind('click', function(event) {
									var button = thisObj.delUserDialog.parent().find('#keys-delete-btn');
                                    if (thisObj.delUserDialog.find('.checkbox.checked').size() != 0)
                                        button.removeAttr('disabled').removeClass('ui-state-disabled');
                                    else
                                        button.prop('disabled', true).addClass('ui-state-disabled');
								});
								thisObj.delUserDialog.dialog('open');
							}
						},
						'Delete_UserGroup' : {
							"name" : account_deleteusergroup,
							callback : function(key, opt) {
	      				        var itemsToDelete = [];
	      				        var $tableWrapper = thisObj.tableWrapper;
	      				        itemsToDelete = $tableWrapper.innertable('getSelectedRows', 1);
	      				        var matrix = [];
	      				        $.each(itemsToDelete,function(idx, key){        
	      				          $.ajax({
	      				          type:"POST",
	      				          url:"ea.cloudmanagement.UserGroupAction$getUserGroupByAccount.json",
	      				          data:{account: key},
	      				          dataType:"json",
	      				          async:false,
		      				          success:function(data){
		      				        	  $.each(data, function(idx, val) {
	          				        			matrix.push([val.name,
	            				        			         $.i18n.map.usergroup_name+': '+val.name+'\n'+
	            				        			         $.i18n.map.usergroup_account+': '+val.account+'\n'+
	            				        			         $.i18n.map.usergroup_status+': '+val.status,
	            				        			         false]);
		      				        	  });
		      				          },
	      				          });
	      				        });

	      				        if ( matrix.length > 0 ) {
	      				          thisObj.delUserGroupDialog.eucadialog('setSelectedResourcesWithCheckbox', {contents: matrix});
	      				          thisObj.delUserGroupDialog.find(".selected-resources").hcheckbox();
	      				        }
	      				        thisObj.delUserGroupDialog.find('.checkbox').bind('click', function(event) {
                                    var button = thisObj.delUserGroupDialog.parent().find('#keys-delete-btn');
                                    if (thisObj.delUserGroupDialog.find('.checkbox.checked').size() != 0)
                                        button.removeAttr('disabled').removeClass('ui-state-disabled');
                                    else
                                        button.prop('disabled', true).addClass('ui-state-disabled');
                                });
								thisObj.delUserGroupDialog.dialog('open');
							}
						},
						'Manage_Policy' : {
							"name" : policy_manage,
							callback : function(key, opt) {
                                var items = thisObj.tableWrapper.innertable('getSelectedRows', 1);
                                if (items.length != 1) {
                                    notifySuccess($.i18n.prop('error_msg_select_one', DefaultEncoder().encodeForHTML($.i18n.map.policy_subtitle)));
                                    return false;
                                } 
                                var matrix = [];
                                $.ajax({
                                type:"POST",
                                url:"ea.cloudmanagement.PolicyAction$getPolicyByAccount.json",
                                data:{account: items[0]},
                                dataType:"json",
                                async:false,
                                  success:function(data){
                                      $.each(describe('cloudmanagement_policy'), function(idx1,item) {
                                          var flg = false;
                                          $.each(data, function(idx2, checkedItem) {
                                              if (checkedItem.name == item.name) {
                                                  flg = true;
                                                  return false;
                                              }
                                          });
                                          if (flg) {
                                             matrix.push([item.name,
                                                          $.i18n.map.policy_name+': '+item.name+'\n'+
                                                          $.i18n.map.policy_type+': '+item.type+'\n'+
                                                          $.i18n.map.policy_action+': '+item.action+'\n'+
                                                          $.i18n.map.policy_resource+': '+item.resource+'\n'+
                                                          $.i18n.map.policy_condition+': '+item.condition+'\n'+
                                                          $.i18n.map.policy_effect+': '+item.effect,
                                                          true]); 
                                          } else {
                                             matrix.push([item.name,
                                                          $.i18n.map.policy_name+': '+item.name+'\n'+
                                                          $.i18n.map.policy_type+': '+item.type+'\n'+
                                                          $.i18n.map.policy_action+': '+item.action+'\n'+
                                                          $.i18n.map.policy_resource+': '+item.resource+'\n'+
                                                          $.i18n.map.policy_condition+': '+item.condition+'\n'+
                                                          $.i18n.map.policy_effect+': '+item.effect,
                                                          false]);                                      
                                          }
                                      });
                                  },
                                });
                                if ( matrix.length > 0 ) {
                                  thisObj.policyDialog.eucadialog('setSelectedResourcesWithCheckbox', {contents: matrix});
                                  thisObj.policyDialog.find(".selected-resources").hcheckbox();
                                }
                                thisObj.policyDialog.dialog('open');
							}
						}
					};
          },

      }); //end of eucatable
        

      var $wrapper = $('<div>').addClass('innertable-wrapper');
      $configurecloud.appendTo($wrapper);
      $wrapper.appendTo(this.element);
      
    },
      
    _create : function() { 
    	var thisObj = this;
        var $tmpl = $('html body').find('#deleteDlgTmpl').clone();
        var $rendered = $($tmpl.render($.extend($.i18n.map)));
        var $del_dialog = $rendered.children().first();
        $del_dialog.find(".selected-resources").before($.i18n.map.text_del_component);
        this.delDialog = $del_dialog.eucadialog({
           id: 'keys-delete',
           title: account_deletaccount,
           width: 500,
           buttons: {
             'delete': {text: button_delete, click: function() {
                  var itemsToDelete = thisObj.delDialog.eucadialog('getSelectedResourcesString',1);
                  $del_dialog.eucadialog("close");
                  thisObj._deleteAction(itemsToDelete);
              }},
             'cancel': {text: button_cancel, focus:true, click: function() { $del_dialog.eucadialog("close");}} 
           },
         });
        
        var $tmpl = $('html body').find('#deleteMultipleDlgTmpl').clone();
        var $rendered = $($tmpl.render($.extend($.i18n.map)));
        var $delUser_dialog = $rendered.children().first();
        $delUser_dialog.find(".selected-resources").before($.i18n.map.text_del_selectcontent);
        this.delUserDialog = $delUser_dialog.eucadialog({
           id: 'keys-delete',
           width: 500,
           title: account_deleteuser,
           buttons: {
             'delete': {
                 domid : 'keys-delete-btn',
                 disabled : true,
            	 text: button_delete, 
            	 click: function() {
                  var itemsToDelete = thisObj.delUserDialog.eucadialog('getSelectedCheckedResources');
                  if (itemsToDelete.length < 1) {
                	  thisObj.delUserDialog.eucadialog('showError',error_msg_multiple_delete);
                  } else {
                      $delUser_dialog.eucadialog("close");
                      thisObj._deleteUserAction(itemsToDelete);
                  }
               }},
             'cancel': {text: button_cancel, focus:true, click: function() { $delUser_dialog.eucadialog("close");}} 
           },
         });
        
        var $tmpl = $('html body').find('#deleteMultipleDlgTmpl').clone();
        var $rendered = $($tmpl.render($.extend($.i18n.map)));
        var $delUserGroup_dialog = $rendered.children().first();
        $delUserGroup_dialog.find(".selected-resources").before($.i18n.map.text_del_selectcontent);
        this.delUserGroupDialog = $delUserGroup_dialog.eucadialog({
           id: 'keys-delete',
           width: 500,
           title: account_deleteusergroup,
           buttons: {
             'delete': {
                 domid : 'keys-delete-btn',
                 disabled : true,
            	 text: button_delete, 
            	 click: function() {
                  var itemsToDelete = thisObj.delUserGroupDialog.eucadialog('getSelectedCheckedResources');
                  if (itemsToDelete.length < 1) {
                	  thisObj.delUserGroupDialog.eucadialog('showError',error_msg_multiple_delete);
                  } else {
                      $delUserGroup_dialog.eucadialog("close");
                      thisObj._deleteUserGroupAction(itemsToDelete);
                  }
               }},
             'cancel': {text: button_cancel, focus:true, click: function() { $delUserGroup_dialog.eucadialog("close");}} 
           },
         });
        
        var $tmpl = $('html body').find('#deleteMultipleDlgTmpl').clone();
        var $rendered = $($tmpl.render($.extend($.i18n.map)));
        var $delPolicy_dialog = $rendered.children().first();
        $delPolicy_dialog.find(".selected-resources").before($.i18n.map.text_del_selectcontent);
        this.delPolicyDialog = $delPolicy_dialog.eucadialog({
           id: 'keys-delete',
           width: 500,
           title: account_deletepolicy,
           buttons: {
             'delete': {
            	 text: button_delete, 
            	 click: function() {
                  var itemsToDelete = thisObj.delPolicyDialog.eucadialog('getSelectedCheckedResources');
                  if (itemsToDelete.length < 1) {
                	  thisObj.delPolicyDialog.eucadialog('showError',error_msg_multiple_delete);
                  } else {
                      $delUser_dialog.eucadialog("close");
                      thisObj._deleteUserGroupAction(itemsToDelete);
                  }
               }},
             'cancel': {text: button_cancel, focus:true, click: function() { $delPolicy_dialog.eucadialog("close");}} 
           },
         });
        
    	var createButtonId = "keys-add-btn";
        var $tmpl = $('html body div.templates').find('#addAccountDlgTmpl').clone();       
        var $rendered = $($tmpl.render($.extend($.i18n.map)));
        var $add_dialog = $rendered.children().first();
        this.addDialog = $add_dialog.eucadialog({
            id: 'keys-add',
            title: account_addaccount,
            width: 500,
            buttons: { 
            // e.g., add : { domid: keys-add-btn, text: "Add new key", disabled: true, focus: true, click : function() { }, keypress : function() { }, ...} 
		    'create' : {
								domid : createButtonId,
								text : button_add,
								disabled : true,
								click : function() {
									var name = $.trim(asText($add_dialog.find('#name').val()));
									$add_dialog.eucadialog("close");
									var model = {name: name};
									thisObj._addAction(model);
									;
								}
							},
			'cancel' : {
								domid : 'keys-cancel-btn',
								text : button_cancel,
								click : function() {
									$add_dialog.eucadialog("close");
								}
							},
						},
          });
        
        $add_dialog.find("#name").watermark(watermark_input_name);
        $add_dialog.eucadialog('buttonOnKeyupNew', $add_dialog.find('#name'), createButtonId, function(val){
            var name = $.trim($add_dialog.find('#name').val());
            if (!INFRASTRACTURE_NAME_PATTERN.test(name)){
            	thisObj.addDialog.eucadialog('showError',error_msg_infrastracture_name);
            } else {
            	thisObj.addDialog.eucadialog('showError',null);
            }
            return INFRASTRACTURE_NAME_PATTERN.test(name);
          });
        
    	var createUserButtonId = "keys-add-user-btn";
        var $tmpl = $('html body div.templates').find('#addUserDlgTmpl').clone();       
        var $rendered = $($tmpl.render($.extend($.i18n.map)));
        var $addUser_dialog = $rendered.children().first();
        this.addUserDialog = $addUser_dialog.eucadialog({
            id: 'keys-add',
            title: account_adduser,
            width: 500,
            buttons: { 
            // e.g., add : { domid: keys-add-btn, text: "Add new key", disabled: true, focus: true, click : function() { }, keypress : function() { }, ...} 
		    'create' : {
								domid : createUserButtonId,
								text : button_add,
								disabled : true,
								click : function() {
									var name = $.trim(asText($addUser_dialog.find('#name').val()));
									var account = $.trim(asText($addUser_dialog.find('#account').html()));
									$addUser_dialog.eucadialog("close");
									var model = {name: name, account: account};
									thisObj._addUserGroupAction(model);
								}
							},
			'cancel' : {
								domid : 'keys-cancel-btn',
								text : button_cancel,
								click : function() {
									$addUser_dialog.eucadialog("close");
								}
							},
						},
          });
        
        $addUser_dialog.find("#name").watermark(watermark_input_name);
        $addUser_dialog.eucadialog('buttonOnKeyupNew', $addUser_dialog.find('#name'), createUserButtonId, function(val){
            var name = $.trim($addUser_dialog.find('#name').val());
            if (!INFRASTRACTURE_NAME_PATTERN.test(name)){
            	thisObj.addUserDialog.eucadialog('showError',error_msg_infrastracture_name);
            } else {
            	thisObj.addUserDialog.eucadialog('showError',null);
            }
            return INFRASTRACTURE_NAME_PATTERN.test(name);
          });
        
    	var createUserGroupButtonId = "keys-add-usergroup-btn";
        var $tmpl = $('html body div.templates').find('#addUserDlgTmpl').clone();       
        var $rendered = $($tmpl.render($.extend($.i18n.map)));
        var $addUserGroup_dialog = $rendered.children().first();
        this.addUserGroupDialog = $addUserGroup_dialog.eucadialog({
            id: 'keys-add',
            title: account_addusergroup,
            width: 500,
            buttons: { 
            // e.g., add : { domid: keys-add-btn, text: "Add new key", disabled: true, focus: true, click : function() { }, keypress : function() { }, ...} 
		    'create' : {
								domid : createUserGroupButtonId,
								text : button_add,
								disabled : true,
								click : function() {
									var name = $.trim(asText($addUserGroup_dialog.find('#name').val()));
									var account = $.trim(asText($addUserGroup_dialog.find('#account').html()));
									$addUserGroup_dialog.eucadialog("close");
									var model = {name: name, account: account};
									thisObj._addUserGroupAction(model);
								}
							},
			'cancel' : {
								domid : 'keys-cancel-btn',
								text : button_cancel,
								click : function() {
									$addUserGroup_dialog.eucadialog("close");
								}
							},
						},
          });
        
        $addUserGroup_dialog.find("#name").watermark(watermark_input_name);
        $addUserGroup_dialog.eucadialog('buttonOnKeyupNew', $addUserGroup_dialog.find('#name'), createUserGroupButtonId, function(val){
            var name = $.trim($addUserGroup_dialog.find('#name').val());
            if (!INFRASTRACTURE_NAME_PATTERN.test(name)){
            	thisObj.addUserGroupDialog.eucadialog('showError',error_msg_infrastracture_name);
            } else {
            	thisObj.addUserGroupDialog.eucadialog('showError',null);
            }
            return INFRASTRACTURE_NAME_PATTERN.test(name);
          });
    
        var $tmpl = $('html body').find('#deleteMultipleDlgTmpl').clone();
        var $rendered = $($tmpl.render($.extend($.i18n.map)));
        var $policy_dialog = $rendered.children().first();
        this.policyDialog = $policy_dialog.eucadialog({
            id : 'keys-delete',
            width : 500,
            title : policy_manage,
            buttons : {
                'save' : {
                    text : button_save,
                    click : function() {
                        var items = thisObj.policyDialog.eucadialog('getSelectedCheckedResources');
                        if (items.length < 1) {
                            thisObj.policyDialog.eucadialog('showError', error_msg_multiple_delete);
                        } else {
                            $policy_dialog.eucadialog("close");
                            thisObj._policyAction(items);
                        }
                    }
                },
                'cancel' : {
                    text : button_cancel,
                    focus : true,
                    click : function() {
                        $policy_dialog.eucadialog("close");
                    }
                }
            },
        });

    },
    
    _deleteAction : function(itemsToDelete) {
        $.ajax({
        	type:"POST",
        	url:"ea.cloudmanagement.AccountAction$deleteAccount.json",
            data:{items : itemsToDelete},
            dataType:"json",
            async:false,
            success:
            function(data, textStatus, jqXHR){
              var notifyMsg = "";
              $.each(data, function(idx, value) {
            	  notifyMsg += ("name:"+ value + "<br>");
              });
              notifySuccess($.i18n.map.success_msg_del, notifyMsg);
              require(['app'], function(app) { 
              	app.data.cloudmanagement_account.fetch(); 
              });
              thisObj.tableWrapper.innertable('refreshTable');
            },
            error:
            function(jqXHR, textStatus, errorThrown){
            	notifyError($.i18n.map.error_msg_del, getErrorMessage(jqXHR));
            }
         });
      },

    _addAction : function(model) {
        $.ajax({
          type:"POST",
          url:"ea.cloudmanagement.AccountAction$addAccount.json",
          data:model,
          dataType:"json",
          async:false,
          success:
          function(data, textStatus, jqXHR){
        	notifySuccess($.i18n.map.success_msg_add, "name:"+ data.name);
            require(['app'], function(app) { 
            	app.data.cloudmanagement_account.fetch(); 
            });
            thisObj.tableWrapper.innertable('refreshTable');
          },
          error:
          function(jqXHR, textStatus, errorThrown){
            notifyError($.i18n.map.error_msg_add, getErrorMessage(jqXHR));
          }
       });
     },
     
     _deleteUserAction : function(itemsToDelete) {
         $.ajax({
         	type:"POST",
         	url:"ea.cloudmanagement.UserAction$deleteUser.json",
             data:{items : itemsToDelete},
             dataType:"json",
             async:false,
             success:
             function(data, textStatus, jqXHR){
               var notifyMsg = "";
               $.each(data, function(idx, value) {
             	  notifyMsg += ("name:"+ value + "<br>");
               });
               notifySuccess($.i18n.map.success_msg_del, notifyMsg);
               require(['app'], function(app) { 
               	app.data.cloudmanagement_user.fetch(); 
               });
             },
             error:
             function(jqXHR, textStatus, errorThrown){
             	notifyError($.i18n.map.error_msg_del, getErrorMessage(jqXHR));
             }
          });
       },

     _addUserAction : function(model) {
         $.ajax({
           type:"POST",
           url:"ea.cloudmanagement.UserAction$addUser.json",
           data:model,
           dataType:"json",
           async:false,
           success:
           function(data, textStatus, jqXHR){
         	notifySuccess($.i18n.map.success_msg_add, "name:"+ data.name);
             require(['app'], function(app) { 
             	app.data.cloudmanagement_user.fetch(); 
             });
           },
           error:
           function(jqXHR, textStatus, errorThrown){
             notifyError($.i18n.map.error_msg_add, getErrorMessage(jqXHR));
           }
        });
      },
      
      _deleteUserGroupAction : function(itemsToDelete) {
          $.ajax({
          	type:"POST",
          	url:"ea.cloudmanagement.UserGroupAction$deleteUserGroup.json",
              data:{items : itemsToDelete},
              dataType:"json",
              async:false,
              success:
              function(data, textStatus, jqXHR){
                var notifyMsg = "";
                $.each(data, function(idx, value) {
              	  notifyMsg += ("name:"+ value + "<br>");
                });
                notifySuccess($.i18n.map.success_msg_del, notifyMsg);
                require(['app'], function(app) { 
                	app.data.cloudmanagement_usergroup.fetch(); 
                });
              },
              error:
              function(jqXHR, textStatus, errorThrown){
              	notifyError($.i18n.map.error_msg_del, getErrorMessage(jqXHR));
              }
           });
        },

      _addUserGroupAction : function(items) {
          $.ajax({
            type:"POST",
            url:"ea.cloudmanagement.UserGroupAction$deleteUserGroup.json",
            data:model,
            dataType:"json",
            async:false,
            success:
            function(data, textStatus, jqXHR){
          	notifySuccess($.i18n.map.success_msg_add, "name:"+ data.name);
              require(['app'], function(app) { 
              	app.data.cloudmanagement_usergroup.fetch(); 
              });
            },
            error:
            function(jqXHR, textStatus, errorThrown){
              notifyError($.i18n.map.error_msg_add, getErrorMessage(jqXHR));
            }
         });
       },
       
       _policyAction : function(items) {
           alert(1);
       }
  });
})(jQuery,
   window.eucalyptus ? window.eucalyptus : window.eucalyptus = {});
