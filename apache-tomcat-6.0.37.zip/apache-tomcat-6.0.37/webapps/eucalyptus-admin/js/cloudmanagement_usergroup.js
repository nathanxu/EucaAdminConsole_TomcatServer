/*************************************************************************
 * Copyright 2009-2012 Eucalyptus Systems, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/.
 *
 * Please contact Eucalyptus Systems, Inc., 6755 Hollister Ave., Goleta
 * CA 93117, USA or visit http://www.eucalyptus.com/licenses/ if you need
 * additional information or have any questions.
 ************************************************************************/

(function($, eucalyptus) {
  $.widget('eucalyptus.cloudmanagement_usergroup', $.eucalyptus.eucawidget, {
    options : { },
    baseTable : null,
    tableWrapper : null,
    _init : function() {
      var thisObj = this;
      var $tmpl = $('html body div.templates').find('#usergroupTmpl').clone();    
      var $wrapper = $($tmpl.render($.i18n.map));
      var $configurecloud = $wrapper.children().first();
      var $help = $wrapper.children().last(); 
      
      var $instTable = $configurecloud.children('.inner-table');
      thisObj.tableWrapper = $instTable.innertable({
          id : 'cloudmanagement_usergroup', // user of this widget should customize these options,
          data_deps: ['cloudmanagement_usergroup'],
          hidden: thisObj.options['hidden'],
          dt_arg : {
            "sAjaxSource": 'cloudmanagement_usergroup',
            "aaSorting": [[ 3, "desc" ]],
            "aoColumnDefs": [
              {
                "bSortable": false,
                "aTargets":[0],
                "mData": function(source) { return '<input type="checkbox"/>' },
                "sClass": "checkbox-cell",
              },
              {
                "aTargets":[1],
                "mData": function(source) { 
                  return source.name;
                },
              },
              {
            	"aTargets":[2],
                "mData": function(source){
                  return source.account;
                },
              },
              {
                "aTargets":[3],
                "mData": function(source) { 
                	return source.status;
                },
              }
            ]
          },
          text : {
            create_resource : gloable_new,
            resource_found : 'record_found',
            resource_search : record_search,
            resource_plural : record_plural,
          },
          menu_click_create : function(e) {
        	  var accounts = describe('cloudmanagement_account');
        	  var $accountArea = thisObj.addDialog.find('#account');
        	  $.each(accounts, function(idx, act) {
        		  $accountArea.append($('<option>').attr('value', act.name).text(act.name));
        	  });
        	  thisObj.addDialog.eucadialog('open');
          },            
          menu_actions : function(args){
              return {
                'Delete' : {
                    "name" : gloable_delete,
                    callback : function(key, opt) {
                        var itemsToDelete = [];
                        var $tableWrapper = thisObj.tableWrapper;
                        itemsToDelete = $tableWrapper.innertable('getSelectedRows', 1);
                        var matrix = [];
                        $.each(itemsToDelete,function(idx, key){
                          matrix.push([key, key]);
                        });

                        if ( itemsToDelete.length > 0 ) {
                          thisObj.delDialog.eucadialog('setSelectedResources', {title:[title_sc], contents: matrix, limit:60, hideColumn: 1});
                          thisObj.delDialog.dialog('open');
                        }
                    }
                },
                'Manage_User' : {
                    "name" : usergroup_manageuser,
                    callback : function(key, opt) {
                        items = thisObj.tableWrapper.innertable('getSelectedRows', 1);
                        if (items.length != 1) {
                            notifySuccess($.i18n.prop('error_msg_select_one', DefaultEncoder().encodeForHTML($.i18n.map.user_subtitle)));
                            return false;
                        } 
                        var matrix = [];
                        $.ajax({
                        type:"POST",
                        url:"ea.cloudmanagement.UserGroupAction$getUserGroupByUser.json",
                        data:{account: "11"},
                        dataType:"json",
                        async:false,
                          success:function(data){
                              $.each(describe('cloudmanagement_usergroup'), function(idx1,ug) {
                                  var flg = false;
                                  $.each(data, function(idx2, checkedUg) {
                                      if (checkedUg.name == ug.name) {
                                          flg = true;
                                          return false;
                                      }
                                  });
                                  if (flg) {
                                     matrix.push([ug.name,
                                         $.i18n.map.usergroup_name+': '+ug.name+'\n'+
                                         $.i18n.map.usergroup_account+': '+ug.account+'\n'+
                                         $.i18n.map.usergroup_status+': '+ug.status,
                                         true]);   
                                  } else {
                                     matrix.push([ug.name,
                                         $.i18n.map.usergroup_name+': '+ug.name+'\n'+
                                         $.i18n.map.usergroup_account+': '+ug.account+'\n'+
                                         $.i18n.map.usergroup_status+': '+ug.status,
                                         false]);                                         
                                  }
                              });
                          },
                        });
                        if ( matrix.length > 0 ) {
                          thisObj.manageUserDialog.eucadialog('setSelectedResourcesWithCheckbox', {contents: matrix});
                          thisObj.manageUserDialog.find(".selected-resources").hcheckbox();
                        }
                        thisObj.manageUserDialog.dialog('open');
                    }
                },
                'Manage_Policy' : {
                    "name" : usergroup_managepolicy,
                    callback : function(key, opt) {
                        items = thisObj.tableWrapper.innertable('getSelectedRows', 1);
                        if (items.length != 1) {
                            notifySuccess($.i18n.prop('error_msg_select_one', DefaultEncoder().encodeForHTML($.i18n.map.user_subtitle)));
                            return false;
                        } 
                        var matrix = [];
                        $.ajax({
                        type:"POST",
                        url:"ea.cloudmanagement.UserGroupAction$getUserGroupByUser.json",
                        data:{account: "11"},
                        dataType:"json",
                        async:false,
                          success:function(data){
                              $.each(describe('cloudmanagement_usergroup'), function(idx1,ug) {
                                  var flg = false;
                                  $.each(data, function(idx2, checkedUg) {
                                      if (checkedUg.name == ug.name) {
                                          flg = true;
                                          return false;
                                      }
                                  });
                                  if (flg) {
                                     matrix.push([ug.name,
                                         $.i18n.map.usergroup_name+': '+ug.name+'\n'+
                                         $.i18n.map.usergroup_account+': '+ug.account+'\n'+
                                         $.i18n.map.usergroup_status+': '+ug.status,
                                         true]);   
                                  } else {
                                     matrix.push([ug.name,
                                         $.i18n.map.usergroup_name+': '+ug.name+'\n'+
                                         $.i18n.map.usergroup_account+': '+ug.account+'\n'+
                                         $.i18n.map.usergroup_status+': '+ug.status,
                                         false]);                                         
                                  }
                              });
                          },
                        });
                        if ( matrix.length > 0 ) {
                          thisObj.managePolicyDialog.eucadialog('setSelectedResourcesWithCheckbox', {contents: matrix});
                          thisObj.managePolicyDialog.find(".selected-resources").hcheckbox();
                        }
                        thisObj.managePolicyDialog.dialog('open');
                    }
                }

            };
          },
          draw_cell_callback : null, 
          expand_callback : function(row){ // row = [col1, col2, ..., etc]
            return thisObj._expandCallback(row);
          }
      }); //end of eucatable

      var $wrapper = $('<div>').addClass('innertable-wrapper');
      $configurecloud.appendTo($wrapper);
      $wrapper.appendTo(this.element);
      
    },
      
      _create : function() { 
      	var thisObj = this;
        var $tmpl = $('html body').find('#deleteDlgTmpl').clone();
        var $rendered = $($tmpl.render($.extend($.i18n.map)));
        var $del_dialog = $rendered.children().first();
        $del_dialog.find(".selected-resources").before($.i18n.map.text_del_component);
        this.delDialog = $del_dialog.eucadialog({
           id: 'keys-delete',
           title: account_deleteusergroup,
           width: 500,
           buttons: {
             'delete': {text: button_delete, click: function() {
                  var itemsToDelete = thisObj.delDialog.eucadialog('getSelectedResourcesString',1);
                  $del_dialog.eucadialog("close");
                  thisObj._deleteAction(itemsToDelete);
              }},
             'cancel': {text: button_cancel, focus:true, click: function() { $del_dialog.eucadialog("close");}} 
           },
         });
           
        var createButtonId = "keys-add-btn";
        var $tmpl = $('html body div.templates').find('#addUserGroupDlgTmpl').clone();
        var $rendered = $($tmpl.render($.extend($.i18n.map)));
        var $add_dialog = $rendered.children().first();
        this.addDialog = $add_dialog.eucadialog({
            id : 'keys-add',
            title : account_addusergroup,
            width : 500,
            buttons : {
                // e.g., add : { domid: keys-add-btn, text: "Add new key", disabled: true, focus: true, click : function() { }, keypress : function() { }, ...}
                'create' : {
                    domid : createButtonId,
                    text : button_add,
                    disabled : true,
                    click : function() {
                        var name = $.trim(asText($add_dialog.find('#name').val()));
                        var account = $.trim(asText($add_dialog.find('#account').val()));
                        $add_dialog.eucadialog("close");
                        var model = {
                            name : name,
                            account : account
                        };
                        thisObj._addAction(model);
                        ;
                    }
                },
                'cancel' : {
                    domid : 'keys-cancel-btn',
                    text : button_cancel,
                    click : function() {
                        $add_dialog.eucadialog("close");
                    }
                },
            },
        });

        $add_dialog.find("#name").watermark(watermark_input_name);
        $add_dialog.eucadialog('buttonOnKeyupNew', $add_dialog.find('#name'), createButtonId, function(val) {
            var name = $.trim($add_dialog.find('#name').val());
            if (!INFRASTRACTURE_NAME_PATTERN.test(name)) {
                thisObj.addDialog.eucadialog('showError', error_msg_infrastracture_name);
            } else {
                thisObj.addDialog.eucadialog('showError', null);
            }
            return INFRASTRACTURE_NAME_PATTERN.test(name);
        }); 

        var $tmpl = $('html body').find('#deleteMultipleDlgTmpl').clone();
        var $rendered = $($tmpl.render($.extend($.i18n.map)));
        var $manageUser_dialog = $rendered.children().first();
        this.manageUserDialog = $manageUser_dialog.eucadialog({
           id: 'keys-delete',
           width: 500,
           title: usergroup_manageuser,
           buttons: {
             'delete': {
                 text: gloable_save, 
                 click: function() {
                  var items = thisObj.manageUserDialog.eucadialog('getSelectedCheckedResources');
                  if (items.length < 1) {
                      thisObj.manageUserDialog.eucadialog('showError',error_msg_multiple_delete);
                  } else {
                      $manageUser_dialog.eucadialog("close");
                      thisObj._userAction(items);
                  }
               }},
             'cancel': {text: button_cancel, focus:true, click: function() { $manageUser_dialog.eucadialog("close");}} 
           },
         });
         
        var $tmpl = $('html body').find('#deleteMultipleDlgTmpl').clone();
        var $rendered = $($tmpl.render($.extend($.i18n.map)));
        var $managePolicy_dialog = $rendered.children().first();
        this.managePolicyDialog = $managePolicy_dialog.eucadialog({
           id: 'keys-delete',
           width: 500,
           title: usergroup_managepolicy,
           buttons: {
             'delete': {
                 text: gloable_save, 
                 click: function() {
                  var items = thisObj.managePolicyDialog.eucadialog('getSelectedCheckedResources');
                  if (items.length < 1) {
                      thisObj.managePolicyDialog.eucadialog('showError',error_msg_multiple_delete);
                  } else {
                      $managePolicy_dialog.eucadialog("close");
                      thisObj._policyAction(items);
                  }
               }},
             'cancel': {text: button_cancel, focus:true, click: function() { $managePolicy_dialog.eucadialog("close");}} 
           },
         });                     
      },
      
      _deleteAction : function(itemsToDelete) {
          var thisObj = this;
          $.ajax({
          	type:"POST",
          	url:"ea.cloudmanagement.UserGroupAction$deleteUserGroup.json",
              data:{items : itemsToDelete},
              dataType:"json",
              async:false,
              success:
              function(data, textStatus, jqXHR){
                var notifyMsg = "";
                $.each(data, function(idx, value) {
              	  notifyMsg += ("name:"+ value + "<br>");
                });
                notifySuccess($.i18n.map.success_msg_del, notifyMsg);
                require(['app'], function(app) { 
                	app.data.cloudmanagement_usergroup.fetch(); 
                });
                thisObj.tableWrapper.innertable('refreshTable');
              },
              error:
              function(jqXHR, textStatus, errorThrown){
              	notifyError($.i18n.map.error_msg_del, getErrorMessage(jqXHR));
              }
           });
        },

      _addAction : function(model) {
          var thisObj = this;
          $.ajax({
            type:"POST",
            url:"ea.cloudmanagement.UserAction$addUser.json",
            data:model,
            dataType:"json",
            async:false,
            success:
            function(data, textStatus, jqXHR){
          	notifySuccess($.i18n.map.success_msg_add, "name:"+ data.name);
            require(['app'], function(app) { 
              app.data.cloudmanagement_usergroup.fetch(); 
            });
            thisObj.tableWrapper.innertable('refreshTable');
            },
            error:
            function(jqXHR, textStatus, errorThrown){
              notifyError($.i18n.map.error_msg_add, getErrorMessage(jqXHR));
            }
         });
       },
       
       _userAction : function(items) {
            alert(1);    
       },
       
       _policyAction : function(items) {
           alert(2);
       }
  });
})(jQuery,
   window.eucalyptus ? window.eucalyptus : window.eucalyptus = {});
