/*************************************************************************
 * Copyright 2009-2012 Eucalyptus Systems, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/.
 *
 * Please contact Eucalyptus Systems, Inc., 6755 Hollister Ave., Goleta
 * CA 93117, USA or visit http://www.eucalyptus.com/licenses/ if you need
 * additional information or have any questions.
 ************************************************************************/

(function($, eucalyptus) {
  $.widget('eucalyptus.cloudmanagement_manageimage', $.eucalyptus.eucawidget, {
    options : { },
    baseTable : null,
    tableWrapper : null,
    _init : function() {
      var thisObj = this;
      var $tmpl = $('html body div.templates').find('#manageimageTmpl').clone();    
      var $wrapper = $($tmpl.render($.i18n.map));
      var $configurecloud = $wrapper.children().first();
      var $help = $wrapper.children().last(); 
      
      var $instTable = $configurecloud.children('.inner-table');
      thisObj.tableWrapper = $instTable.innertable({
          id : 'cloudmanagement_manageimage', // user of this widget should customize these options,
          data_deps: ['cloudmanagement_manageimage'],
          hidden: thisObj.options['hidden'],
          dt_arg : {
            "sAjaxSource": 'cloudmanagement_manageimage',
            "aaSorting": [[ 3, "desc" ]],
            "aoColumnDefs": [
              {
                "bSortable": false,
                "aTargets":[0],
                "mData": function(source) { return '<input type="checkbox"/>' },
                "sClass": "checkbox-cell",
              },
              {
                "aTargets":[1],
                "mData": function(source) { 
                  return source;
                },
              },
              {
            	"aTargets":[2],
                "mData": function(source){
                  return '123';
                },
              },
              {
                "aTargets":[3],
                "mData": function(source) { 
                	return '456';
                },
              },
              {
                  "aTargets":[4],
                  "mData": function(source) { 
                    return source;
                  },
                },
                {
              	"aTargets":[5],
                  "mData": function(source){
                    return '123';
                  },
                },
                {
                  "aTargets":[6],
                  "mData": function(source) { 
                  	return '456';
                  },
                },
                {
                    "aTargets":[7],
                    "mData": function(source) { 
                      return source;
                    },
                  },
                  {
                	"aTargets":[8],
                    "mData": function(source){
                      return '123';
                    },
                  },
                  {
                    "aTargets":[9],
                    "mData": function(source) { 
                    	return '456';
                    },
                  }
            ]
          },
          text : {
            create_resource : '',
            resource_found : 'record_found',
            resource_search : record_search,
            resource_plural : record_plural,
          },
          menu_click_create : function(e) {
            alert('New')
          },            
          menu_actions : function(args){
        	  return {
        		  	  'Deregister': {"name": manageimage_deregister, callback: function(key, opt) { thisObj._deleteAction(); } },
        	  		  'Permission': {"name": manageimage_permission, callback: function(key, opt) { thisObj._deleteAction(); } }        	  		 };
          },

          draw_cell_callback : null, 
          expand_callback : function(row){ // row = [col1, col2, ..., etc]
            return thisObj._expandCallback(row);
          }
      }) //end of eucatable
        

      var $wrapper = $('<div>').addClass('innertable-wrapper');
      $configurecloud.appendTo($wrapper);
      $wrapper.appendTo(this.element);
      
    },
    _expandCallback : function(row){ 
    	return null;
      },
      
    _create : function() { 
    },

    _destroy : function() { },

    close: function() {
      this._super('close');
    }
  });
})(jQuery,
   window.eucalyptus ? window.eucalyptus : window.eucalyptus = {});
