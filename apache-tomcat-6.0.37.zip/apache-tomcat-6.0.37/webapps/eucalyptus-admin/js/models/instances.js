define([
    'models/eucacollection',
    'models/instance'
], function(EucaCollection, Instance) {
    var Instances = EucaCollection.extend({
	    model: Instance,
	    url: 'ea.instance.InstanceAction$query.json',
    });
    return Instances;
});
