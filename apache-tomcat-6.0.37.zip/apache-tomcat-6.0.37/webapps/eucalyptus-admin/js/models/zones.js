define([
    'models/eucacollection',
    'models/zone'
], function(EucaCollection, Zone) {
    return EucaCollection.extend({
	model: Zone,
	url: 'ea.zones.ZoneAction$queryAvailabilityZones.json'
    });
});
