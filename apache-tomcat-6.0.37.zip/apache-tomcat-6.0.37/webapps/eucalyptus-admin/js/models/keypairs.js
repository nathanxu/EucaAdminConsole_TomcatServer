define([
    'models/eucacollection',
    'models/keypair'
], function(EucaCollection, Model) {
    return EucaCollection.extend({
	model: Model,
	url: 'ea.keypair.KeypairAction$query.json'
    });
});
