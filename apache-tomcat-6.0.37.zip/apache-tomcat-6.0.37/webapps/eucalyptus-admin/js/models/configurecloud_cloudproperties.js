define([
    'models/eucacollection',
    'models/configurecloud_cloudproperty'
], function(EucaCollection, Model) {
    return EucaCollection.extend({
	model: Model,
	url: 'ea.configurecloud.CloudpropertiesAction$query.json'
    });
});
