define([
    'models/eucacollection',
    'models/configurecloud_dnsservice'
], function(EucaCollection, Model) {
    return EucaCollection.extend({
	model: Model,
	url: 'ea.configurecloud.DnsserviceAction$query.json'
    });
});
