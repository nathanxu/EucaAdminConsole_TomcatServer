define([
    'models/eucacollection',
    'models/cloudmanagement_manageimage'
], function(EucaCollection, Model) {
    return EucaCollection.extend({
	model: Model,
	url: 'ea.cloudmanagement.ManageImageAction$query.json'
    });
});
