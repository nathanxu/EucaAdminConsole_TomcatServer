define([
    'models/eucacollection',
    'models/balancer'
], function(EucaCollection, Model) {
    return EucaCollection.extend({
	model: Model,
	url: 'ea.balancers.BalancerAction$queryBalancers.json'
    });
});
