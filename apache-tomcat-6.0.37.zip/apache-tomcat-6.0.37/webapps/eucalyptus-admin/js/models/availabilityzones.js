define([
    'models/eucacollection',
    'models/availabilityzone'
], function(EucaCollection, AvailabilityZone) {
    var collection = EucaCollection.extend({
      model: AvailabilityZone,
      url: 'ea.zones.ZoneAction$queryAvailabilityZones.json'
    });
    return collection;
});
