define([
    'models/eucacollection',
    'models/launchconfig'
], function(EucaCollection, LaunchConfig) {
    var collection = EucaCollection.extend({
      model: LaunchConfig,
      url: 'ea.configurations.LaunchConfigurationAction$queryLaunchConfigurations.json',
    });
    return collection;
});
