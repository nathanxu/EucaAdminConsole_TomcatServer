define([
    'models/eucacollection',
    'models/scalingpolicy'
], function(EucaCollection, Model) {
    return EucaCollection.extend({
	model: Model,
	url: 'ea.policies.PolicieAction$queryPolicies.json'
    });
});
