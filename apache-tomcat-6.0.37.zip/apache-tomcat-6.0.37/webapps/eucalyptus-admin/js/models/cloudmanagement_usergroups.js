define([
    'models/eucacollection',
    'models/cloudmanagement_usergroup'
], function(EucaCollection, Model) {
    return EucaCollection.extend({
	model: Model,
	url: 'ea.cloudmanagement.UserGroupAction$query.json'
    });
});
