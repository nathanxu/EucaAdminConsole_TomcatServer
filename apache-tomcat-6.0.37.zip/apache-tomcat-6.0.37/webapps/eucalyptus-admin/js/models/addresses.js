define([
    'models/eucacollection',
    'models/address'
], function(EucaCollection, Address) {
    var collection = EucaCollection.extend({
      model: Address,
      url: 'ea.address.AddressAction$query.json'
    });
    return collection;
});
