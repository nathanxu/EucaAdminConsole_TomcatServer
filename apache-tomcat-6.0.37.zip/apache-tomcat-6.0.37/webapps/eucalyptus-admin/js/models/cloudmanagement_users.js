define([
    'models/eucacollection',
    'models/cloudmanagement_user'
], function(EucaCollection, Model) {
    return EucaCollection.extend({
	model: Model,
	url: 'ea.cloudmanagement.UserAction$query.json'
    });
});
