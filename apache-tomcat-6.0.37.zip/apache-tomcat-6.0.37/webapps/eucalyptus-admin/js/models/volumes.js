define([
    'models/eucacollection',
    'models/volume'
], function(EucaCollection, Volume) {
        var Volumes = EucaCollection.extend({
	      model: Volume,
	      url: 'ea.volume.VolumeAction$query.json',
        });
        return Volumes;
});
