define([
    'models/eucacollection',
    'models/cloudmanagement_healthchecking'
], function(EucaCollection, Healthchecking) {
	return EucaCollection.extend({
	    model: Healthchecking,
	    url: 'ea.cloudmanagement.HealthCheckingAction$query.json',
    });
});

