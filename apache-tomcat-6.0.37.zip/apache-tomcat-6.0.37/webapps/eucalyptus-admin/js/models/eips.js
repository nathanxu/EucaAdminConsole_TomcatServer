define([
    'models/eucacollection',
    'models/eip'
], function(EucaCollection, Model) {
    return EucaCollection.extend({
	model: Model,
	url: 'ea.address.AddressAction$query.json'
    });
});
